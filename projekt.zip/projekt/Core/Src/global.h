/*
 * global.h
 *
 *  Created on: Jan 15, 2020
 *      Author: ivant
 */

#ifndef SRC_GLOBAL_H_
#define SRC_GLOBAL_H_
extern volatile int cena;
#endif /* SRC_GLOBAL_H_ */
